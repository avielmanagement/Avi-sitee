import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';

import Home from './Home';
import EzEvPage from './EzEvPage';
import JunkDemoPage from './JunkDemoPage';
import RoofingPage from './RoofingPage';
import GeneralConstructionPage from './GeneralConstructionPage';
import ServiceAreas from './ServiceAreas';
import About from './About';
import GetQuote from './GetQuote';
import StickyCursor from './StickyCursor';
import PrivacyPolicy from './PrivacyPolicy';
import TermsOfService from './TermsOfService';

/**
 * Root router for the Vite app.
 *
 * Note: This project uses HashRouter so routes work on static hosting (Vercel)
 * without needing special rewrites.
 */
const App: React.FC = () => {
  return (
    <HashRouter>
      <StickyCursor />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/ez-ev" element={<EzEvPage />} />
        <Route path="/junk-demo" element={<JunkDemoPage />} />
        <Route path="/roofing" element={<RoofingPage />} />
        <Route path="/general-construction" element={<GeneralConstructionPage />} />
        <Route path="/service-areas" element={<ServiceAreas />} />
        <Route path="/about" element={<About />} />
        <Route path="/get-quote" element={<GetQuote />} />

        {/* Legal pages (required for SMS compliance / trust center) */}
        <Route path="/privacy" element={<PrivacyPolicy />} />
        <Route path="/terms" element={<TermsOfService />} />

        {/* Back-compat / simple 404 */}
        <Route path="/privacy-policy" element={<Navigate to="/privacy" replace />} />
        <Route path="/terms-of-service" element={<Navigate to="/terms" replace />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </HashRouter>
  );
};

export default App;
