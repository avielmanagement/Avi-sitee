import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Home from "./Home";
import EzEvPage from "./EzEvPage";
import JunkDemoPage from "./JunkDemoPage";
import RoofingPage from "./RoofingPage";
import GeneralConstructionPage from "./GeneralConstructionPage";
import ServiceAreas from "./ServiceAreas";
import About from "./About";
import GetQuote from "./GetQuote";
import StickyCursor from "./StickyCursor";

import PrivacyPolicy from "./PrivacyPolicy";
import Terms from "./Terms";

const App: React.FC = () => {
  return (
    <BrowserRouter>
      <StickyCursor />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/ez-ev" element={<EzEvPage />} />
        <Route path="/junk-demo" element={<JunkDemoPage />} />
        <Route path="/roofing" element={<RoofingPage />} />
        <Route path="/general-construction" element={<GeneralConstructionPage />} />
        <Route path="/service-areas" element={<ServiceAreas />} />
        <Route path="/about" element={<About />} />
        <Route path="/get-quote" element={<GetQuote />} />

        {/* legal */}
        <Route path="/privacy" element={<PrivacyPolicy />} />
        <Route path="/terms" element={<Terms />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;
